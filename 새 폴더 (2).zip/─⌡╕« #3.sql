CREATE TABLE Toon_table(
N_toon VARCHAR(45) NOT NULL PRIMARY KEY,
N_toon VARCHAR(45) NOT NULL PRIMARY KEY,
toon_num INT(45) NOT NULL,
Toon_category VARCHAR(45) NOT NULL,
Toon_id INT(10) NOT NULL,
Toon_update INT(10),
Toon_newupdate  INT(10),
Toon_Hit_toon INT(10),
Toon_imagelink VARCHAR(60)
)DEFAULT CHARSET=utf8
