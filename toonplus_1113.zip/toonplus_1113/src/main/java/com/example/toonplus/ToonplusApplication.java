package com.example.toonplus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ToonplusApplication {

    public static void main(String[] args) {
        SpringApplication.run(ToonplusApplication.class, args);
    }

}
