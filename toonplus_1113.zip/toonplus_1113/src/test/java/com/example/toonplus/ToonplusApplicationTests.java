package com.example.toonplus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ToonplusApplicationTests {

    @Test
    void contextLoads() {
    }

}
