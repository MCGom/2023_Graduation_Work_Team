package kr.com.toonplus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ToonPlusApplicationTests {

	@Test
	void contextLoads() {
	}

}
